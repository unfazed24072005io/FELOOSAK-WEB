import React, { createContext, useContext, useState, useMemo, useEffect } from 'react';
import { db, collection, getDocs, addDoc, deleteDoc, doc, query, where } from './firebase';
import { auth } from './firebase';

// === TYPES ===
export type Region = 'egypt' | 'uae';

export interface RegionData {
  region: Region;
  id: string;
  name: string;
  nameAr: string;
  flag: string;
  currency: string;
  currencyAr: string;
  vatRate: number;
  vatLabel: string;
  authority: string;
  ctRate: number;
  ctThreshold: number;
  eMandatory: boolean;
  archival: number;
}

export interface Tx {
  id: string;
  type: 'in' | 'out';
  amount: number;
  category: string;
  note: string;
  date: string;
  customer?: string;
  synced: boolean;
}

export interface Customer {
  id: string;
  name: string;
  nameAr: string;
  phone: string;
  owed: number;
  paid: number;
  trust: number;
}

// === REGION CONSTANTS ===
export const egyptData: RegionData = {
  region: 'egypt', id: 'EG', name: 'Egypt', nameAr: 'مصر',
  flag: '🇪🇬', currency: 'EGP', currencyAr: 'ج.م',
  vatRate: 0.14, vatLabel: 'VAT 14%', authority: 'ETA',
  ctRate: 0.225, ctThreshold: 0, eMandatory: true, archival: 7
};

export const uaeData: RegionData = {
  region: 'uae', id: 'AE', name: 'UAE', nameAr: 'الإمارات',
  flag: '🇦🇪', currency: 'AED', currencyAr: 'د.إ',
  vatRate: 0.05, vatLabel: 'VAT 5%', authority: 'FTA',
  ctRate: 0.09, ctThreshold: 375000, eMandatory: false, archival: 5
};

// === CONTEXT TYPE ===
interface AppState {
  region: Region | null;
  R: RegionData | null;
  lang: string;
  isAr: boolean;
  authed: boolean;
  tab: number;
  txs: Tx[];
  custs: Customer[];
  totalIn: number;
  totalOut: number;
  balance: number;
  totalOwed: number;
  
  login: () => void;
  logout: () => void;
  setRegion: (r: Region) => void;
  setLang: (l: string) => void;
  setTab: (t: number) => void;
  addTx: (tx: Tx) => Promise<void>;
  deleteTx: (id: string) => Promise<void>;
  loadData: () => Promise<void>;
}

const AppContext = createContext<AppState | null>(null);

// === PROVIDER ===
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [region, setRegionState] = useState<Region | null>(null);
  const [lang, setLangState] = useState<string>('en');
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState(0);
  const [txs, setTxs] = useState<Tx[]>([]);
  const [custs, setCusts] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);

  const isAr = lang === 'ar';
  const R = region === 'egypt' ? egyptData : region === 'uae' ? uaeData : null;

  // Load data from Firebase
  const loadData = async () => {
    const user = auth.currentUser;
    if (!user) {
      setTxs([]);
      setCusts([]);
      return;
    }

    try {
      // Load transactions
      const txsQuery = query(collection(db, "transactions"), where("userId", "==", user.uid));
      const txsSnapshot = await getDocs(txsQuery);
      const loadedTxs = txsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Tx[];
      setTxs(loadedTxs);

      // Load customers
      const custsQuery = query(collection(db, "customers"), where("userId", "==", user.uid));
      const custsSnapshot = await getDocs(custsQuery);
      const loadedCusts = custsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Customer[];
      setCusts(loadedCusts);
    } catch (error) {
      console.error("Error loading data:", error);
    }
  };

  // Add transaction to Firebase
  const addTx = async (tx: Tx) => {
    const user = auth.currentUser;
    if (!user) {
      console.error("No user logged in");
      return;
    }

    try {
      const newTx = {
        ...tx,
        userId: user.uid,
        createdAt: new Date().toISOString()
      };
      const docRef = await addDoc(collection(db, "transactions"), newTx);
      setTxs(prev => [{ ...tx, id: docRef.id }, ...prev]);
    } catch (error) {
      console.error("Error adding transaction:", error);
    }
  };

  // Delete transaction from Firebase
  const deleteTx = async (id: string) => {
    try {
      await deleteDoc(doc(db, "transactions", id));
      setTxs(prev => prev.filter(t => t.id !== id));
    } catch (error) {
      console.error("Error deleting transaction:", error);
    }
  };

  useEffect(() => {
    document.documentElement.dir = isAr ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [isAr, lang]);

  // Check auth state and load data
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (user) {
        setAuthed(true);
        await loadData();
      } else {
        setAuthed(false);
        setTxs([]);
        setCusts([]);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const login = () => {
    // Login is handled by Firebase auth in your Login component
    setAuthed(true);
  };
  
  const logout = async () => {
    await auth.signOut();
    setAuthed(false);
    setRegionState(null);
    setTxs([]);
    setCusts([]);
  };

  const setRegion = (r: Region) => {
    setRegionState(r);
  };

  const setLang = (l: string) => setLangState(l);

  const totalIn = useMemo(() => txs.filter(t => t.type === 'in').reduce((s, t) => s + (t.amount || 0), 0), [txs]);
  const totalOut = useMemo(() => txs.filter(t => t.type === 'out').reduce((s, t) => s + (t.amount || 0), 0), [txs]);
  const balance = totalIn - totalOut;
  const totalOwed = useMemo(() => custs.reduce((s, c) => s + (c.owed || 0), 0), [custs]);

  const value = {
    region, R, lang, isAr, authed, tab, txs, custs,
    totalIn, totalOut, balance, totalOwed,
    login, logout, setRegion, setLang, setTab, addTx, deleteTx, loadData
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}